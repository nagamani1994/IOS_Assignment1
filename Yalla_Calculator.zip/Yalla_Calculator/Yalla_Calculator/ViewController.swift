//
//  ViewController.swift
//  Yalla_Calculator
//
//  Created by Yalla,Nagamani on 2/17/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var displayLabel: UILabel!
    
    var val1 = ""
    var val2 = ""
    var result = ""
    var operation = ""
    var givenVal = ""
    var MethodChange = false
    var inChainMode = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func AC(_ sender: UIButton) {
        clearAll()
    }
    
    func clearAll(){
        val1 = ""
        val2 = ""
        MethodChange = false
        operation = ""
        givenVal = ""
        displayLabel.text = ""
        inChainMode = false
    }
    
    func setData(_ number: String){
        if displayLabel.text == "0"{
            displayLabel.text = ""
        }
        else{
            if !MethodChange{
                displayLabel.text! += number
                val1 += number
            }
            else{
                if !inChainMode{
                    displayLabel.text! += number
                    val2 += number
                }
                else{
                    displayLabel.text = ""
                    displayLabel.text! += number
                    val2 += number
                }
            }
        }
    }
    
    func calTemp(_ operation:String)->String {
        if val1 != "" && val2 != ""{
            if operation == "+"{
                val1 = String(Double(val1)! + Double(val2)!)
                givenVal = val2
                val2 = ""
                return String(val1)
            }
            if operation == "-"{
                val1 = String(Double(val1)! - Double(val2)!)
                givenVal = val2
                val2 = ""
                return String(val1)
            }
            if operation == "*"{
                val1 = String(Double(val1)! * Double(val2)!)
                givenVal = val2
                val2 = ""
                return String(val1)
            }
            if operation == "/"{
                val1 = String(Double(val1)! / Double(val2)!)
                givenVal = val2
                val2 = ""
                return String(val1)
            }
            if operation == "%" {
                let s1 = Double(val1)!
                let s2 = Double(val2)!
                var r = s1.remainder(dividingBy: s2)
                val1 = String(r)
                givenVal = val2
                val2 = ""
                return String(val1)
            }
        }
        return ""
    }
    
    func resultFormatter(_ result:String)->String {
        let value = Double(result)!
        var resultStr = String(round(value * 100000) / 100000.0)
        if resultStr.contains(".0"){
            resultStr.removeSubrange(resultStr.index(resultStr.endIndex, offsetBy: -2)..<resultStr.endIndex)
        }
        return resultStr
    }
    
    @IBAction func C(_ sender: UIButton) {
        val2 = ""
        displayLabel.text = ""
    }
    
    @IBAction func PlusorMinus(_ sender: UIButton) {
        if val1 == ""{
            displayLabel.text = "-" + displayLabel.text!
            val1 = "\(displayLabel.text!)"
        }
        else{
            displayLabel.text = "-" + displayLabel.text!
            val2 = "\(displayLabel.text!)"
        }
    }
    
    @IBAction func divide(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "/"
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        if temp != "" {
            // inChainmode = true
            if val2 != ""{
                inChainMode = true
                if MethodChange {
                    result = String(Double(temp)! / Double(val2)!)
                    print(result)
                    if result == "inf"{
                        displayLabel.text! = "Error"
                    }
                    else{
                        displayLabel.text! = resultFormatter(result)
                    }
                }
            }
        }
        MethodChange = true
    }
    
    @IBAction func multiplication(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "*"
        givenVal=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        MethodChange = true
    }
    
    @IBAction func minus(_ sender: UIButton) {
        if(val1 == ""){
           val1 = "0"
        }
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "-"
        givenVal=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        MethodChange = true
    }
    
    @IBAction func plus(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "+"
        givenVal=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        MethodChange = true
    }
    
    @IBAction func equals(_ sender: UIButton) {
        var res = ""
        switch operation {
            case "+":
            if givenVal != "" {
                res = String(Double(val1)! + Double(givenVal)!)
                displayLabel.text = resultFormatter(res)
                val2 = givenVal
            }
            else{
                res = String(Double(val1)! + Double(val2)!)
                displayLabel.text = resultFormatter(res)
            }
            val1 = res
            break
            case "*":
            if givenVal != "" {
                res = String(Double(val1)! * Double(givenVal)!)
                displayLabel.text = resultFormatter(res)
            }
            else{
                res = String(Double(val1)! * Double(val2)!)
                displayLabel.text = resultFormatter(res)
            }
            val1 = res
            break
            case "-":
            if givenVal != "" {
                res = String(Double(val1)! - Double(givenVal)!)
                displayLabel.text = resultFormatter(res)
            }
            else {
                res = String(Double(val1)! - Double(val2)!)
                displayLabel.text = resultFormatter(res)
            }
            val1 = res
            break
            case "/":
            if displayLabel.text == "Error"{
                clearAll()
            }
            else {
                if givenVal != "" {
                    res = String(Double(val1)! / Double(givenVal)!)
                    if res == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }
                    else {
                        displayLabel.text = resultFormatter(res)
                    }
                }
                else {
                    res = String(Double(val1)! / Double(val2)!)
                    if res == "inf"{
                        displayLabel.text! = "Error"
                        return
                    }
                    else {
                        displayLabel.text = resultFormatter(res)
                    }
                }
                val1 = res
            }
            break
            case "%":
            if givenVal != "" {
                displayLabel.text = resultFormatter(res)
                let s1 = Double(val1)!
                let s2 = Double(givenVal)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                val2 = givenVal
            }
            else {
                let s1 = Double(val1)!
                let s2 = Double(val2)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                displayLabel.text = resultFormatter(res)
            }
            val1 = res
            break
        default:
            print("IOS")
        }
    }
    
    @IBAction func reminder(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "%"
        givenVal=""
        displayLabel.text = (temp != "") ? resultFormatter(temp) : ""
        MethodChange = true
    }
    
    @IBAction func dot(_ sender: UIButton) {
        setData(".")
    }
    
    @IBAction func zero(_ sender: UIButton) {
        setData("0")
    }
    
    @IBAction func one(_ sender: UIButton) {
        setData("1")
    }
    
    @IBAction func two(_ sender: UIButton) {
        setData("2")
    }
    
    @IBAction func three(_ sender: UIButton) {
        setData("3")
    }
    
    @IBAction func four(_ sender: UIButton) {
        setData("4")
    }
    
    @IBAction func five(_ sender: UIButton) {
        setData("5")
    }
    
    @IBAction func six(_ sender: UIButton) {
        setData("6")
    }
    
    @IBAction func seven(_ sender: UIButton) {
        setData("7")
    }
    
    @IBAction func eight(_ sender: UIButton) {
        setData("8")
    }
    
    @IBAction func nine(_ sender: UIButton) {
        setData("9")
    }
    
}

